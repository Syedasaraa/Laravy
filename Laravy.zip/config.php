<?php

$conn = mysqli_connect('localhost','root','','shop') or die('connection failed');

?>